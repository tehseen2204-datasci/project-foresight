# Project FORESIGHT – AI-Powered Demand & Inventory Intelligence Platform

## Problem
Businesses lose money two ways: stockouts (lost sales) and overstock (locked capital). FORESIGHT forecasts SKU-level demand and converts it into inventory actions.

## Approach
1. **Data** – 40 SKUs × 730 days of daily sales (price, promo flag, lead time, unit cost). Simulated with weekly/annual seasonality, trend, promos, festive spike.
2. **Features** – lags (1/7/14/28), rolling means (7/28), day-of-week, month, day-of-year, promo, price, SKU/category.
3. **Model** – Gradient Boosting Regressor, time-based split (last 60 days = test). Compared to a naive "same day last week" baseline.
4. **Forecast** – recursive 30-day forecast per SKU.
5. **Inventory logic** – Safety stock = Z·σ·√LT (95% service level), Reorder point = demand×LT + safety stock, EOQ, days of cover.
6. **Risk flags** – STOCKOUT RISK / REORDER NOW / OVERSTOCK / HEALTHY with action recommendations, revenue at risk and capital locked.
7. **Dashboard** – interactive HTML (Chart.js): KPIs, forecast chart, inventory health, feature importance, filterable SKU table.

## Results (hold-out 60 days)
| Metric | Model | Naive |
|---|---|---|
| MAE | 7.78 | 13.61 |
| WAPE | 9.1% | 15.9% |
Model is ~43% more accurate than the naive baseline.

## Files
- `foresight_pipeline.py` – full code (run: `pip install pandas numpy scikit-learn && python foresight_pipeline.py`)
- `foresight_sales_data.csv`, `foresight_30day_forecast.csv`, `foresight_inventory_recommendations.csv`
- `foresight_dashboard.html` – open in any browser

## Limitations & next steps
Data is simulated (swap `generate_data()` for real data). Stock-on-hand is simulated. Future: prophet/LightGBM ensemble, prediction intervals, multi-echelon inventory, Streamlit deployment.
