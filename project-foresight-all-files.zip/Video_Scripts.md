# Demo Video script (3-4 min) – screen record with Loom / OBS, upload to YouTube (unlisted) or Drive (anyone with link)

1. **0:00 Intro (20s)** – "Hi, I'm Tehseen. This is Project FORESIGHT, an AI-powered demand and inventory intelligence platform."
2. **0:20 Problem (20s)** – Stockouts lose sales, overstock locks capital. Goal: forecast SKU demand and recommend stock actions.
3. **0:40 Data (30s)** – Show `foresight_sales_data.csv`. Say clearly it is simulated: 40 SKUs, 730 days, with seasonality, promos, trend.
4. **1:10 Code (60s)** – Open `foresight_pipeline.py`: features (lags, rolling means), Gradient Boosting, time-based split, naive baseline, 30-day recursive forecast, safety stock / reorder point / EOQ.
5. **2:10 Results (30s)** – Run the script in terminal; show MAE 7.78 vs 13.61 and WAPE 9.1% vs 15.9%.
6. **2:40 Dashboard (60s)** – Open the dashboard: KPI cards, forecast chart, health chart, filter table by STOCKOUT RISK, read one recommendation.
7. **3:40 Close (15s)** – "Next: real data, prediction intervals, Streamlit deployment. Thank you."

# Feedback Video script (1-2 min)

- **Learned:** end-to-end forecasting workflow – time-based validation (no leakage), lag features, and how safety stock, reorder point and EOQ turn forecasts into decisions.
- **Challenges:** no dataset was provided, so I built a realistic simulated one and was transparent about it; recursive forecasting accumulates error; choosing sensible stock-risk thresholds.
- **Takeaways:** a model is only useful when connected to a decision; always compare with a naive baseline; next time I would start with real data and add prediction intervals.
- **Thanks** to mentor Chandan Mishra and Zidio for the opportunity.
