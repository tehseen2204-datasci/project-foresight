"""
Project FORESIGHT - AI-Powered Demand & Inventory Intelligence Platform
Pipeline: synthetic data -> EDA -> SKU-level demand forecast (ML) -> inventory
policy (safety stock, reorder point, EOQ) -> stockout/overstock risk -> outputs.
NOTE: Replace generate_data() with your real dataset if Zidio provides one
(needs columns: date, sku, category, units_sold, price, promo, stock_on_hand).
"""
import json
import numpy as np, pandas as pd
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error

rng = np.random.default_rng(42)

# ---------- 1. DATA ----------
def generate_data(n_sku=40, days=730):
    dates = pd.date_range("2024-10-01", periods=days, freq="D")
    cats = ["Beverages", "Snacks", "Personal Care", "Household", "Staples"]
    rows = []
    for i in range(n_sku):
        cat = cats[i % len(cats)]
        base = rng.uniform(15, 120)
        price = rng.uniform(20, 400)
        trend = rng.uniform(-0.0003, 0.0012)
        seas_amp = rng.uniform(0.05, 0.35)
        phase = rng.uniform(0, 2 * np.pi)
        lead = int(rng.integers(3, 12)); cost = price * rng.uniform(0.5, 0.75)
        for t, d in enumerate(dates):
            promo = int(rng.random() < 0.08)
            dow = 1 + 0.18 * (d.dayofweek >= 5)
            seas = 1 + seas_amp * np.sin(2 * np.pi * t / 365 + phase)
            fest = 1.35 if d.month in (10, 11) and d.day <= 20 else 1.0   # festive season
            mu = base * (1 + trend * t) * dow * seas * fest * (1.4 if promo else 1)
            units = rng.poisson(max(mu, 0.5))
            rows.append((d, f"SKU{i+1:03d}", cat, units, round(price, 2), promo, lead, round(cost, 2)))
    df = pd.DataFrame(rows, columns=["date","sku","category","units_sold","price","promo","lead_time_days","unit_cost"])
    return df

df = generate_data()
df.to_csv("foresight_sales_data.csv", index=False)

# ---------- 2. FEATURES ----------
df = df.sort_values(["sku", "date"]).reset_index(drop=True)
g = df.groupby("sku")["units_sold"]
for l in (1, 7, 14, 28):
    df[f"lag_{l}"] = g.shift(l)
df["roll7"] = g.transform(lambda s: s.shift(1).rolling(7).mean())
df["roll28"] = g.transform(lambda s: s.shift(1).rolling(28).mean())
df["dow"] = df.date.dt.dayofweek
df["month"] = df.date.dt.month
df["doy"] = df.date.dt.dayofyear
df["sku_code"] = df.sku.str[3:].astype(int)
df["cat_code"] = df.category.astype("category").cat.codes
FEATS = ["lag_1","lag_7","lag_14","lag_28","roll7","roll28","dow","month","doy","promo","price","sku_code","cat_code"]
df = df.dropna().reset_index(drop=True)

# ---------- 3. MODEL (time-based split) ----------
cut = df.date.max() - pd.Timedelta(days=60)
train, test = df[df.date <= cut], df[df.date > cut]
model = GradientBoostingRegressor(n_estimators=300, max_depth=4, learning_rate=0.05, subsample=0.8, random_state=42)
model.fit(train[FEATS], train.units_sold)
pred = model.predict(test[FEATS]).clip(0)

# naive baseline = same day last week
base = test["lag_7"]
mae_m, mae_b = mean_absolute_error(test.units_sold, pred), mean_absolute_error(test.units_sold, base)
rmse_m = mean_squared_error(test.units_sold, pred) ** 0.5
wape_m = np.abs(test.units_sold - pred).sum() / test.units_sold.sum() * 100
wape_b = np.abs(test.units_sold - base).sum() / test.units_sold.sum() * 100
metrics = dict(MAE_model=round(mae_m,2), MAE_naive=round(mae_b,2), RMSE_model=round(rmse_m,2),
               WAPE_model_pct=round(wape_m,2), WAPE_naive_pct=round(wape_b,2),
               improvement_vs_naive_pct=round((1 - mae_m / mae_b) * 100, 1))
print("Metrics:", metrics)
imp = pd.Series(model.feature_importances_, index=FEATS).sort_values(ascending=False)

# ---------- 4. 30-DAY FORECAST (recursive) ----------
H = 30
hist = df[["date","sku","category","units_sold","price","promo","sku_code","cat_code","lead_time_days","unit_cost"]].copy()
full = pd.read_csv("foresight_sales_data.csv", parse_dates=["date"])
fc_rows = []
for sku, s in full.groupby("sku"):
    s = s.sort_values("date"); vals = list(s.units_sold.values)
    meta = s.iloc[-1]; last = s.date.max()
    for h in range(1, H + 1):
        d = last + pd.Timedelta(days=h)
        x = pd.DataFrame([{
            "lag_1": vals[-1], "lag_7": vals[-7], "lag_14": vals[-14], "lag_28": vals[-28],
            "roll7": np.mean(vals[-7:]), "roll28": np.mean(vals[-28:]),
            "dow": d.dayofweek, "month": d.month, "doy": d.dayofyear, "promo": 0,
            "price": meta.price, "sku_code": int(sku[3:]), "cat_code": pd.Categorical([meta.category], categories=sorted(full.category.unique())).codes[0]}])
        p = float(max(model.predict(x[FEATS])[0], 0)); vals.append(p)
        fc_rows.append((sku, d, p))
fc = pd.DataFrame(fc_rows, columns=["sku","date","forecast_units"])
fc.to_csv("foresight_30day_forecast.csv", index=False)

# ---------- 5. INVENTORY INTELLIGENCE ----------
resid_sd = (test.units_sold - pred).groupby(test.sku).std()
sku_meta = full.groupby("sku").agg(category=("category","first"), price=("price","last"),
            lead=("lead_time_days","first"), cost=("unit_cost","first"))
avg_d = fc.groupby("sku").forecast_units.mean()
Z = 1.65  # 95% service level
inv = sku_meta.join(avg_d.rename("avg_daily_forecast")).join(resid_sd.rename("sigma"))
inv["safety_stock"] = (Z * inv.sigma * np.sqrt(inv.lead)).round()
inv["reorder_point"] = (inv.avg_daily_forecast * inv.lead + inv.safety_stock).round()
hold = 0.22 * inv.cost / 365; order_cost = 500
inv["eoq"] = np.sqrt(2 * inv.avg_daily_forecast * 365 * order_cost / (0.22 * inv.cost)).round()
# simulated current stock on hand (some deliberately too low / too high)
inv["stock_on_hand"] = (inv.avg_daily_forecast * rng.uniform(2, 45, len(inv))).round()
inv["days_of_cover"] = (inv.stock_on_hand / inv.avg_daily_forecast).round(1)
def status(r):
    if r.stock_on_hand < r.reorder_point and r.days_of_cover < r.lead: return "STOCKOUT RISK"
    if r.stock_on_hand < r.reorder_point: return "REORDER NOW"
    if r.days_of_cover > 35: return "OVERSTOCK"
    return "HEALTHY"
inv["status"] = inv.apply(status, axis=1)
def rec(r):
    if r.status in ("STOCKOUT RISK","REORDER NOW"):
        return f"Order ~{int(max(r.eoq, r.reorder_point - r.stock_on_hand + r.avg_daily_forecast*r.lead))} units"
    if r.status == "OVERSTOCK": return "Pause replenishment; run markdown/promo"
    return "No action"
inv["recommendation"] = inv.apply(rec, axis=1)
inv["capital_locked_overstock"] = np.where(inv.status=="OVERSTOCK",
    ((inv.stock_on_hand - 30*inv.avg_daily_forecast).clip(lower=0) * inv.cost).round(), 0)
inv["revenue_at_risk_30d"] = np.where(inv.status.isin(["STOCKOUT RISK"]),
    (np.maximum(0, 30*inv.avg_daily_forecast - inv.stock_on_hand) * inv.price).round(), 0)
inv = inv.round(2).reset_index()
inv.to_csv("foresight_inventory_recommendations.csv", index=False)
print(inv.status.value_counts())

# ---------- 6. DASHBOARD PAYLOAD ----------
daily = full.groupby("date").units_sold.sum().reset_index()
recent = daily.tail(120)
fc_tot = fc.groupby("date").forecast_units.sum().reset_index()
cat_sales = full.groupby("category").apply(lambda x: (x.units_sold * x.price).sum()).round().to_dict()
payload = dict(
  metrics=metrics,
  hist_dates=recent.date.dt.strftime("%Y-%m-%d").tolist(), hist_units=recent.units_sold.tolist(),
  fc_dates=fc_tot.date.dt.strftime("%Y-%m-%d").tolist(), fc_units=fc_tot.forecast_units.round(0).tolist(),
  importance=imp.round(4).to_dict(), cat_sales=cat_sales,
  status_counts=inv.status.value_counts().to_dict(),
  kpi=dict(skus=int(len(inv)), revenue_at_risk=float(inv.revenue_at_risk_30d.sum()), capital_locked=float(inv.capital_locked_overstock.sum())),
  table=inv[["sku","category","avg_daily_forecast","stock_on_hand","days_of_cover","reorder_point","safety_stock","eoq","status","recommendation"]].to_dict("records"),
)
json.dump(payload, open("payload.json","w"), default=float)
print(json.dumps(payload["kpi"]), metrics)
